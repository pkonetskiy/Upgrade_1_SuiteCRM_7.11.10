<?php
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
    1 => 'SuiteCRM',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
        0 => '6.5.25'
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'BizForce, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'General',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => 'Upgrade for 7.11.8 SuiteCRM (It is change some mistakes)',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'BizForce',
  'published_date' => '2019-11-10 20:00:00',
  'type' => 'patch',
  'version' => '0.1.0',
);
?>
